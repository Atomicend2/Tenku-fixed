# 🌌 TENKU 天空 — Hosting & Setup Guide

## ✅ Prerequisites

- **Node.js** v20+ (LTS)
- **pnpm** (package manager)
- A **Linux VPS** or server (Ubuntu 22.04 recommended)
- A **WhatsApp account** to use as the bot number

---

## 🚀 Option 1: VPS / Cloud Server (Recommended for 24/7)

### Best free/cheap options:
| Provider | Free Tier | Notes |
|---|---|---|
| **Railway** | $5 credit/month free | Easiest, auto-deploys from GitHub |
| **Render** | Free (sleeps after 15min idle) | Good for testing |
| **Oracle Cloud** | Always Free VPS | Best free 24/7 option |
| **Hetzner** | ~€4/month | Very reliable, fast |
| **DigitalOcean** | $6/month | Simple droplets |

---

## 🛠️ Setup Steps (Ubuntu VPS)

### 1. Install Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node --version  # Should be v20+
```

### 2. Install pnpm
```bash
npm install -g pnpm
```

### 3. Upload your project
```bash
# From your local machine:
scp -r Tenku-fixed/ user@your-server-ip:/home/user/tenku
# OR use git if you push to GitHub
```

### 4. Install dependencies
```bash
cd /home/user/tenku
pnpm install
```

### 5. Set up environment variables
```bash
cp .env.example .env
nano .env
# Fill in: OWNER_NUMBERS, JWT_SECRET, GEMINI_API_KEY
```

### 6. Build the project
```bash
cd artifacts/api-server
pnpm run build
```

### 7. Start the bot
```bash
pnpm run start
```

### 8. Pair your WhatsApp
- Open the web dashboard at `http://your-server-ip:3000`
- Go to **Bot Manager**
- Enter bot name + phone number
- Click **Generate Pairing Code**
- Open WhatsApp → Linked Devices → Link with phone number → Enter the code

---

## 🔄 Keep it Running 24/7 with PM2

```bash
# Install PM2
npm install -g pm2

# Start the bot with PM2
cd /home/user/tenku/artifacts/api-server
pm2 start dist/index.mjs --name "tenku-bot"

# Auto-restart on server reboot
pm2 startup
pm2 save

# Useful PM2 commands:
pm2 logs tenku-bot       # View live logs
pm2 restart tenku-bot    # Restart
pm2 stop tenku-bot       # Stop
pm2 status               # Check status
```

---

## ☁️ Option 2: Railway (Easiest — No VPS needed)

1. Push your project to **GitHub**
2. Go to [railway.app](https://railway.app)
3. Click **New Project → Deploy from GitHub**
4. Select your repo
5. Add environment variables in the Railway dashboard
6. Set **Start Command**: `cd artifacts/api-server && node dist/index.mjs`
7. Done — Railway handles the rest

---

## ☁️ Option 3: Render

1. Push to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect repo
4. **Build Command**: `cd artifacts/api-server && pnpm install && pnpm run build`
5. **Start Command**: `cd artifacts/api-server && node dist/index.mjs`
6. Add env vars in dashboard

> ⚠️ Free tier on Render sleeps after 15 minutes of inactivity. Use a paid plan for 24/7.

---

## 🌐 Setting Up the Web Dashboard

The dashboard runs on the same server as the bot on port 3000.

To access from the internet:
1. Open port 3000 in your server's firewall
2. Visit `http://your-server-ip:3000`
3. Or set up a domain with Nginx as a reverse proxy:

```nginx
server {
    listen 80;
    server_name tenku.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Then get HTTPS with:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d tenku.yourdomain.com
```

---

## 🤖 Multi-Bot Setup

The bot supports up to **5 WhatsApp bots** from the dashboard:

1. Go to the Admin Dashboard → **Bot Manager**
2. Click **Add Bot**
3. Enter bot name + the phone number
4. Upload the bot's menu image
5. Click **Generate Pairing Code**
6. Enter that code in WhatsApp → Linked Devices

Each bot gets its own session folder under `sessions/`.

---

## 📁 Project Structure

```
Tenku-fixed/
├── artifacts/
│   └── api-server/
│       ├── src/
│       │   ├── bot/
│       │   │   ├── commands/     ← All WhatsApp commands
│       │   │   ├── handlers/     ← Message routing, card spawning
│       │   │   ├── db/           ← Database queries
│       │   │   └── assets/       ← Default profile backgrounds
│       │   └── routes/           ← Web API routes
│       └── dist/                 ← Compiled output (after build)
├── .env.example                  ← Copy to .env
└── HOSTING.md                    ← This file
```

---

## 🔑 Owner Commands (WhatsApp)

| Command | Description |
|---|---|
| `.mods` | List all mods and guardians |
| `.bots` | Show all registered bots with status |
| `.post <msg>` | Broadcast to all groups |
| `.ban @user` | Ban a user |
| `.addmod @user` | Add a mod |
| `.addguardian @user` | Add a guardian |
| `.gambling on/off` | Toggle gambling in a group |
| `.ubs` | AI card upload (reply to image) |
| `.ups confirm/cancel` | Confirm or cancel AI card upload |

---

## 🃏 Card Commands

| Command | Description |
|---|---|
| `.claim <code>` | Claim a spawned card by its code |
| `.si <name>` | Search your cards by name |
| `.slb <series>` | Series leaderboard |
| `.tier` | View cards grouped by tier |
| `.myseries` | All series you own |
| `.ci <name> <tier>` | Search master card database |
| `.deck` | View your deck |

---

## ⚙️ Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `OWNER_NUMBERS` | ✅ | Comma-separated owner phone numbers |
| `GEMINI_API_KEY` | ✅ | Google Gemini API key for .ubs |
| `JWT_SECRET` | ✅ | Secret for website JWT tokens |
| `DATABASE_URL` | ✅ | SQLite or PostgreSQL URL |
| `PORT` | Optional | Web server port (default: 3000) |
| `NODE_ENV` | Optional | `production` or `development` |
| `SESSION_DIR` | Optional | Path to store WhatsApp sessions |

---

## 🐛 Troubleshooting

**Bot not recognizing owner?**
→ Check `OWNER_NUMBERS` in `.env` — must be digits only, no `+`, no spaces
→ Restart bot after changing `.env`

**Website login not working?**
→ First register with `.reg` on WhatsApp, then go to website and set a password using your phone number

**Cards not showing images?**
→ Make sure `DATABASE_URL` points to a writable path
→ Cards are stored as binary in the database

**Bot disconnects?**
→ Use PM2 — it auto-restarts on crash
→ Check `pm2 logs tenku-bot` for errors

---

*Built with ❤️ for TENKU 天空*
