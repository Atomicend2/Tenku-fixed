#!/bin/bash
set -e

echo "==> Installing dependencies..."
pnpm install

echo "==> Building frontend (shadow-garden)..."
cd artifacts/shadow-garden
pnpm install
pnpm run build
cd ../..

echo "==> Building backend (api-server)..."
cd artifacts/api-server
pnpm install
pnpm run build
cd ../..

echo "==> Build complete!"
